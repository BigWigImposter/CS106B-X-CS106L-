#include "intvector.h"
#include "MyVector.h"

int main() {
    IntVector vec;
    vec.push_back(1);
    vec.push_back(2);

    // test harness

    return 0;
}

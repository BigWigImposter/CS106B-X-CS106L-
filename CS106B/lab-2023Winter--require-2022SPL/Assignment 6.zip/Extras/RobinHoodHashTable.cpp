/******************************************************************************
 * If you want to, just for funzies, implement Robin Hood hashing and compare
 * it against linear probing, feel free to use this starter file. This is
 * completely optional - we aren't expecting you to code this one up.
 */

#include "RobinHoodHashTable.h"
using namespace std;

RobinHoodHashTable::RobinHoodHashTable(HashFunction<string> hashFn) {
    /* TODO: Delete this comment, then implement this function. */
    (void) hashFn;
}

RobinHoodHashTable::~RobinHoodHashTable() {
    /* TODO: Delete this comment, then implement this function. */
}

int RobinHoodHashTable::size() const {
    /* TODO: Delete this comment and the next line, then implement this function. */
    return -1;
}

bool RobinHoodHashTable::isEmpty() const {
    /* TODO: Delete this comment and the next line, then implement this function. */
    return false;
}

bool RobinHoodHashTable::insert(const string& elem) {
    /* TODO: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

bool RobinHoodHashTable::contains(const string& elem) const {
    /* TODO: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}

bool RobinHoodHashTable::remove(const string& elem) {
    /* TODO: Delete this comment and the next lines, then implement this function. */
    (void) elem;
    return false;
}


/* * * * * * Test Cases Below This Point * * * * * */
#include "GUI/SimpleTest.h"

/* Optional: Add your own custom tests here! */















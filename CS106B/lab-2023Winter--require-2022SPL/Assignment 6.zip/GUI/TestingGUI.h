#pragma once
#include "SimpleTest.h"

namespace MiniGUI {
    namespace Detail {
        void runConsoleModeTests(SimpleTest::TestFilter filter, bool divertStreams);
    }
}
